﻿namespace Core.EntitiesInterfaces
{
    public interface IDamageable
    {
        void TakeDamage(int damage);
    }
}