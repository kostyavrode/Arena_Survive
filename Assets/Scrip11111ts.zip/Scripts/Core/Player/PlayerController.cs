﻿using Core;
using Core.EntitiesInterfaces;
using UnityEngine;
using Zenject;

namespace Player
{
    public class PlayerController : MonoBehaviour, IDamageable
    {
        private GameStateMachine _gameStateMachine;
        
        private PlayerInput _input;
        private PlayerMover _mover;
        private PlayerRotator _rotator;
        private PlayerShooter _shooter;
        private PlayerHealth _health;
        
        private CharacterController _characterController;
        
        [SerializeField] private Transform _shootPosition;
        [SerializeField] private GameObject _bulletPrefab;
        [SerializeField] private int _maxHealth;

        [Inject]
        public void Construct(GameStateMachine gameStateMachine)
        {
            _gameStateMachine = gameStateMachine;
        }

        private void Awake()
        {
            _characterController = GetComponent<CharacterController>();
            
            _input = new PlayerInput();
            _mover = new PlayerMover(_characterController, 5f);
            _rotator = new PlayerRotator(transform);
            _shooter = new PlayerShooter(_bulletPrefab);
            
            _shooter.Initialize(_shootPosition);
            
            _health = new PlayerHealth(_maxHealth);
        }

        private void Update()
        {
            Vector3 movementInput = _input.GetMovementInput();
            _mover.Move(movementInput);
            _rotator.Rotate(movementInput);

            if (Input.GetButtonDown("Fire1"))
            {
                _shooter.Shoot();
            }
        }

        public void TakeDamage(int damage)
        {
            _health.TakeDamage(damage);
        }
    }
}