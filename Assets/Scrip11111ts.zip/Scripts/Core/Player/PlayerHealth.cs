﻿using Core;
using Core.StateMachine;
using UI;
using UI.View;
using UnityEngine;

namespace Player
{
    public class PlayerHealth
    {
        private int _currentHealth;
        private readonly int _maxHealth;

        public PlayerHealth(int maxHealth)
        {
            _maxHealth = maxHealth;
            _currentHealth = maxHealth;
        }

        public void TakeDamage(int amount)
        {
            _currentHealth = Mathf.Clamp(_currentHealth - amount, 0, _maxHealth);

            if (_currentHealth == 0)
            {
                Die();
            }
        }

        private void Die()
        {
            Debug.Log("Player Dead");
        }
    }
}