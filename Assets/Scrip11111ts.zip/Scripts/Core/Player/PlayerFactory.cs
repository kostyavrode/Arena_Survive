﻿using UnityEngine;
using Zenject;

namespace Player
{
    public class PlayerFactory : IFactory<PlayerController>
    {
        private readonly DiContainer _container;
        private readonly GameObject _playerPrefab;

        public PlayerFactory(DiContainer container, GameObject playerPrefab)
        {
            _container = container;
            _playerPrefab = playerPrefab;
        }

        public PlayerController Create()
        {
            GameObject playerObject = _container.InstantiatePrefab(_playerPrefab, PlayerSpawnPoint.SpawnPosition, Quaternion.identity, null);
            return playerObject.GetComponent<PlayerController>();
        }
    }
}