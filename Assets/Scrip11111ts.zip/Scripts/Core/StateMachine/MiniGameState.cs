﻿namespace Core.StateMachine
{
    public class MiniGameState : IState
    {
        public void Enter()
        {
            
        }

        public void Exit()
        {
            
        }
    }
}