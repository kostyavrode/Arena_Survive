﻿using Core.StateMachine;
using UI;
using UI.Model;
using UI.View;
using UI.ViewModel;
using Zenject;

namespace Core
{
    public class Bootstrapper : MonoInstaller
    {
        public override void InstallBindings()
        {
            RegisterUI();
            BindGameStateMachine();
        }

        private void RegisterUI()
        {
            Container.Bind<UIManager>().AsSingle().NonLazy();
            
            Container.Bind<MenuModel>().AsSingle();
            Container.Bind<MenuViewModel>().AsSingle();
            Container.Bind<MenuView>().FromComponentInHierarchy().AsSingle();
            
            Container.Bind<PlayingModel>().AsSingle();
            Container.Bind<PlayingViewModel>().AsSingle();
            Container.Bind<PlayingView>().FromComponentInHierarchy().AsSingle();
            
            Container.Bind<PauseModel>().AsSingle();
            Container.Bind<PauseViewModel>().AsSingle();
            Container.Bind<PauseView>().FromComponentInHierarchy().AsSingle();
            
            Container.Bind<SettingsModel>().AsSingle();
            Container.Bind<SettingsViewModel>().AsSingle();
            Container.Bind<SettingsView>().FromComponentInHierarchy().AsSingle();
        }

        private void BindGameStateMachine()
        {
            Container.Bind<MenuState>().AsSingle();
            Container.Bind<PlayingState>().AsSingle();
            Container.Bind<PauseState>().AsSingle();
            Container.Bind<MiniGameState>().AsSingle();
            Container.Bind<GameOverState>().AsSingle();
            
            Container.BindInterfacesAndSelfTo<GameStateMachine>().AsSingle();
        }
    }
}