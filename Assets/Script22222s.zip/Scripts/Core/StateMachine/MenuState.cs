﻿namespace Core.StateMachine
{
    public class MenuState : IState
    {
        public void Enter()
        {
            
        }

        public void Exit()
        {

        }
    }
}