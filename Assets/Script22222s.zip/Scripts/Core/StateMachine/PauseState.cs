﻿namespace Core.StateMachine
{
    public class PauseState : IState
    {
        public void Enter()
        {
            
        }

        public void Exit()
        {
            
        }
    }
}