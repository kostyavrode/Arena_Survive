﻿using Unity.VisualScripting;

namespace Core.StateMachine
{
    public class GameOverState : IState
    {
        public void Enter()
        {
            
        }

        public void Exit()
        {
            
        }
    }
}