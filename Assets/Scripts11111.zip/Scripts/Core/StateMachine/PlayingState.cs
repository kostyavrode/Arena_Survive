﻿namespace Core.StateMachine
{
    public class PlayingState : IState
    {
        public void Enter()
        {
            
        }

        public void Exit()
        {
            
        }
    }
}